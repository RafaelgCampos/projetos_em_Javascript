let  jog = 1;

function jogador(){
  desenhar();
  jog += 1;
  if (jog == 3)
    jog = 1;
}
